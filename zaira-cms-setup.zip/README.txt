Zaira Imtiyaz — CMS setup

Upload these to the root of the GitHub repository:
- index.html (replace the existing index.html)
- .pages.yml (new file)
- content/posts.json (new file)

The media/images folder can be created automatically when the first image is uploaded in Pages CMS.

After this one-time setup:
1. Open https://app.pagescms.org/
2. Sign in with GitHub.
3. Install/authorize the Pages CMS GitHub App for zairaimtiyaz.github.io.
4. Open the repository.
5. Open “Articles & Poems”.
6. Add a post, upload an image, and save. Pages CMS writes the change to GitHub; GitHub Pages then republishes the site.
